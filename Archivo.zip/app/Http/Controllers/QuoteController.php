<?php

namespace App\Http\Controllers;

use App\Quote;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class QuoteController extends Controller
{
    public function store(Request $request){
        DB::beginTransaction();
            
        try {
            $quote = Quote::create($request->all());
    
            DB::commit();

            return response()->json(['quote' => $quote,'message' => 'Usuario guardado correctamente!']);
        }
        catch (GlobalException $e) {
            DB::rollback();
            throw $e;
        }
    }

    public function update(Request $request){ 
        $request->validate([
            'number_of_guests'  => 'required',
            'type_of_ceremony' => 'required',
        ]);

        $quote = Quote::find($request->id);
        $quote->fill($request->all());
        $quote->save();
        return response()->json(['quote' => $quote,'message' => 'Cotización actualizado correctamente!']);

    }
}
