<?php

return [
    'firebase_dir' => env('FIREBASE_JSON', 'null'),
    'firebase_uri'      => env('FIREBASE_URI','null')
];