@extends('layouts.auth')

@section('auth')
<div class="col-md-8">
    <div class="card-group">
        <div class="card">
            <div class="card-body p-5">
                <div class="text-center d-lg-none">
                    ZEUS
                </div>
            </div>
        </div>
        
    </div>
</div>
@endsection
